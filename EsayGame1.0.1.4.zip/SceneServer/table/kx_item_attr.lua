﻿---自动生成的 不要手动编辑---
---@type kx_item_attr_data[]
local _kx_item_attr_table = 
{
[1] = {name = '最小物理攻击力',idx = 1, },
[2] = {name = '最大物理攻击力',idx = 2, },
[3] = {name = '最小魔法攻击力',idx = 3, },
[4] = {name = '最大魔法攻击力',idx = 4, },
[5] = {name = '物理防御力',idx = 5, },
[6] = {name = '物理防御千分比',idx = 6, },
[7] = {name = '魔法防御力',idx = 7, },
[8] = {name = '魔法防御千分比',idx = 8, },
[9] = {name = '必杀成功率',idx = 9, },
[10] = {name = '魔法必杀成功率',idx = 10, },
[11] = {name = '眩晕',idx = 11, },
[12] = {name = '移动速度',idx = 12, },
[13] = {name = '格挡成功率',idx = 13, },
[14] = {name = '降低对方格挡成功率',idx = 14, },
[15] = {name = '攻击成功率',idx = 15, },
[16] = {name = '生命恢复力',idx = 16, },
[17] = {name = '魔法恢复力',idx = 17, },
[18] = {name = '全体物品获得率',idx = 18, },
[19] = {name = '魔法物品获得率',idx = 19, },
[20] = {name = '力量',idx = 20, },
[21] = {name = '敏捷',idx = 21, },
[22] = {name = '精神',idx = 22, },
[23] = {name = '白魔法',idx = 23, },
[24] = {name = '红魔法',idx = 24, },
[25] = {name = '蓝魔法',idx = 25, },
[26] = {name = '黄魔法',idx = 26, },
[27] = {name = '黑魔法',idx = 27, },
[28] = {name = '红魔法抵抗力',idx = 28, },
[29] = {name = '蓝魔法抵抗力',idx = 29, },
[30] = {name = '黄魔法抵抗力',idx = 30, },
[31] = {name = '魔法抵抗力',idx = 31, },
[32] = {name = 'HP',idx = 32, },
[33] = {name = 'MP',idx = 33, },
[34] = {name = 'MaxHP',idx = 34, },
[35] = {name = 'MaxMP',idx = 35, },
[36] = {name = '物理反弹',idx = 36, },
[37] = {name = '魔法反弹',idx = 37, },
[38] = {name = '集中力',idx = 38, },
[39] = {name = '分散力',idx = 39, },
[40] = {name = '攻击速度',idx = 40, },
[41] = {name = '亡灵系最小攻击力',idx = 41, },
[42] = {name = '亡灵系最大攻击力',idx = 42, },
[43] = {name = '亡灵系防御率',idx = 43, },
[44] = {name = '亡灵系防御力',idx = 44, },
[45] = {name = '生物系最小攻击力',idx = 45, },
[46] = {name = '生物系最大攻击力',idx = 46, },
[47] = {name = '生物系防御率',idx = 47, },
[48] = {name = '生物系防御力',idx = 48, },
[49] = {name = '召唤系最小攻击力',idx = 49, },
[50] = {name = '召唤系最大攻击力',idx = 50, },
[51] = {name = '召唤系防御率',idx = 51, },
[52] = {name = '召唤系防御力',idx = 52, },
[53] = {name = '突击系最小攻击力',idx = 53, },
[54] = {name = '突击系最大攻击力',idx = 54, },
[55] = {name = '突击系防御率',idx = 55, },
[56] = {name = '突击系防御力',idx = 56, },
[57] = {name = '人类系最小攻击力',idx = 57, },
[58] = {name = '人类系最大攻击力',idx = 58, },
[59] = {name = '人类系防御率',idx = 59, },
[60] = {name = '人类系防御力',idx = 60, },
[61] = {name = '精灵系最小攻击力',idx = 61, },
[62] = {name = '精灵系最大攻击力',idx = 62, },
[63] = {name = '精灵系防御率',idx = 63, },
[64] = {name = '精灵系防御力',idx = 64, },
[65] = {name = '物理致命伤害加成',idx = 65, },
[66] = {name = '魔法致命伤害加成',idx = 66, },

}

---@class kx_item_attr_data
local kx_item_attr_data =
{
	
---序号
idx = 0,
---属性名称
name = nil,
}

local indexTable = 
{
	__index = function()
		return kx_item_attr_data
	end,
	__newindex = function (t,k,v)
		error('lua表格不允许修改！！' .. debug.traceback())
	end
}

setmetatable(_kx_item_attr_table, indexTable)

kx_item_attr_table = _kx_item_attr_table
return _kx_item_attr_table