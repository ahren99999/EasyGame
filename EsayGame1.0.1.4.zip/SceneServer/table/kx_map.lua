﻿---自动生成的 不要手动编辑---
---@type kx_map_data[]
local _kx_map_table = 
{
[1] = {x0 = 1,x1 = 50000,y1 = 50000,pk = true,drop_mask = 3,mark = false,idx = 1,bgm = 'Ladianes_Day',map_name = '未知区域',exp = 1,y0 = 1, },
[2] = {x0 = 22757,x1 = 23398,y1 = 34460,pk = true,drop_mask = 1,mark = true,idx = 2,bgm = 'Ladianes_Night',map_name = '莱蒂尼斯城',exp = 1,y0 = 33812, },
[3] = {x0 = 23511,x1 = 23745,y1 = 37651,pk = true,drop_mask = 3,mark = false,idx = 3,bgm = 'AbandonedMine3F_Main',map_name = '副本三',exp = 1,y0 = 37380, },
[4] = {x0 = 26404,x1 = 26546,y1 = 25818,pk = true,drop_mask = 3,mark = true,idx = 4,bgm = 'AbandonedMine3F_Main',map_name = '副本四夜间',exp = 1,y0 = 25645, },
[5] = {x0 = 20800,x1 = 21455,y1 = 29910,pk = true,drop_mask = 3,mark = false,idx = 5,bgm = 'FrozenLand',map_name = '冰封之地',exp = 1,y0 = 29200, },
[6] = {x0 = 25800,x1 = 27300,y1 = 36300,pk = true,drop_mask = 3,mark = true,idx = 6,bgm = 'QuestDungeon01',map_name = '东部区域',exp = 1,y0 = 33800, },
[7] = {x0 = 21668,parent_id = 8,x1 = 21954,y1 = 25297,pk = true,drop_mask = 2,mark = false,idx = 7,bgm = 'NAmb_NephirimDungoen',map_name = '风暴区',exp = 1,y0 = 25102, },
[8] = {x0 = 20800,parent_id = 0,x1 = 23200,y1 = 27300,pk = true,drop_mask = 2,mark = false,idx = 8,bgm = 'VerosNewCastle',map_name = '精灵城',exp = 1,y0 = 24700, },
[9] = {x0 = 21085,parent_id = 2,x1 = 21160,y1 = 28480,pk = true,drop_mask = 0,mark = true,idx = 9,bgm = 'DAmb_Cave',map_name = '黑房',exp = 1,y0 = 28418, },
[10] = {x0 = 20865,parent_id = 2,x1 = 21400,y1 = 28500,pk = true,drop_mask = 3,mark = false,idx = 10,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫二层',exp = 1,y0 = 27900, },
[11] = {x0 = 21930,parent_id = 2,x1 = 21950,y1 = 28514,pk = true,drop_mask = 0,mark = true,idx = 11,bgm = 'AbandonedMine3F_Main',map_name = '蓝色安全地带',exp = 1,y0 = 28480, },
[12] = {x0 = 20900,x1 = 21600,y1 = 28700,pk = true,drop_mask = 3,mark = false,idx = 12,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫一层',exp = 10,y0 = 28600, },
[13] = {x0 = 20812,x1 = 21448,y1 = 34448,pk = true,drop_mask = 3,mark = false,idx = 13,bgm = 'AbandonedMine3F_Main',map_name = '无名岛',exp = 10,y0 = 34210, },
[14] = {x0 = 22574,parent_id = 8,x1 = 22675,y1 = 25177,pk = true,drop_mask = 0,mark = false,idx = 14,bgm = 'AbandonedMine3F_Main',map_name = '废弃的荒地',exp = 1,y0 = 25116, },
[15] = {x0 = 24300,x1 = 24500,y1 = 36330,pk = true,drop_mask = 0,mark = false,idx = 15,bgm = 'PetLand',map_name = '情人岛',exp = 1,y0 = 36240, },
[16] = {x0 = 23465,x1 = 23669,y1 = 37344,pk = true,drop_mask = 3,mark = false,idx = 16,bgm = 'AbandonedMine3F_Main',map_name = '女王洞',exp = 10,y0 = 37104, },
[17] = {x0 = 25455,x1 = 25544,y1 = 25657,pk = true,drop_mask = 0,mark = false,idx = 17,bgm = 'AbandonedMine3F_Main',map_name = '清澈小屋',exp = 10,y0 = 25455, },
[18] = {x0 = 24385,x1 = 24657,y1 = 25172,pk = true,drop_mask = 3,mark = false,idx = 18,bgm = 'AbandonedMine3F_Main',map_name = '瓦特岛80-160',exp = 1,y0 = 24729, },
[19] = {x0 = 24118,x1 = 24416,y1 = 25298,pk = true,drop_mask = 3,mark = false,idx = 19,bgm = 'AbandonedMine3F_Main',map_name = '瓦特岛1-80',exp = 10,y0 = 24930, },
[20] = {x0 = 24141,x1 = 24500,y1 = 29231,pk = true,drop_mask = 3,mark = false,idx = 20,bgm = 'AbandonedMine3F_Main',map_name = '宠物岛',exp = 10,y0 = 28869, },
[21] = {x0 = 23061,parent_id = 8,x1 = 23400,y1 = 28971,pk = true,drop_mask = 3,mark = false,idx = 21,bgm = 'AbandonedMine3F_Main',map_name = '精灵地宫四层',exp = 1,y0 = 28627, },
[22] = {x0 = 22115,x1 = 22750,y1 = 30555,pk = true,drop_mask = 3,mark = false,idx = 22,bgm = 'SealedLand',map_name = '幽灵城',exp = 1,y0 = 29920, },
[23] = {x0 = 22228,parent_id = 22,x1 = 22461,y1 = 30352,pk = true,drop_mask = 3,mark = false,idx = 23,bgm = 'SealedLand',map_name = '幽灵城-内城',exp = 1,y0 = 30130, },
[24] = {x0 = 21500,parent_id = 2,x1 = 21970,y1 = 36370,pk = true,drop_mask = 3,mark = false,idx = 24,bgm = 'SealedLand',map_name = '玄武岛',exp = 1,y0 = 35900, },
[25] = {x0 = 22120,parent_id = 2,x1 = 22560,y1 = 36370,pk = true,drop_mask = 3,mark = false,idx = 25,bgm = 'SealedLand',map_name = '朱雀岛屿',exp = 1,y0 = 35970, },
[26] = {x0 = 20800,x1 = 21450,y1 = 36400,pk = true,drop_mask = 3,mark = false,idx = 26,bgm = 'SealedLand',map_name = '青龙岛屿',exp = 1,y0 = 35800, },
[27] = {x0 = 21880,parent_id = 2,x1 = 21900,y1 = 28520,pk = true,drop_mask = 0,mark = false,idx = 27,bgm = 'AbandonedMine3F_Main',map_name = '红色安全地带',exp = 1,y0 = 28470, },
[28] = {x0 = 21520,parent_id = 2,x1 = 21730,y1 = 28220,pk = true,drop_mask = 3,mark = false,idx = 28,bgm = 'AbandonedMine3F_Main',map_name = '梦魇之殿',exp = 1,y0 = 28000, },
[29] = {x0 = 21489,parent_id = 2,x1 = 22104,y1 = 35744,pk = true,drop_mask = 3,mark = false,idx = 29,bgm = 'SealedLand',map_name = '麒麟岛屿',exp = 1,y0 = 35257, },
[30] = {x0 = 23550,parent_id = 8,x1 = 23890,y1 = 28450,pk = true,drop_mask = 3,mark = false,idx = 30,bgm = 'DephirothChamber2_Road',map_name = '精灵地宫二层',exp = 1,y0 = 28140, },
[31] = {x0 = 21980,parent_id = 2,x1 = 22000,y1 = 28560,pk = true,drop_mask = 3,mark = false,idx = 31,bgm = 'AbandonedMine3F_Main',map_name = '紫色安全区域',exp = 1,y0 = 28485, },
[32] = {x0 = 23150,parent_id = 2,x1 = 23270,y1 = 35240,pk = true,drop_mask = 3,mark = false,idx = 32,bgm = 'AbandonedMine3F_Main',map_name = '人族圣地',exp = 1,y0 = 35155, },
[33] = {x0 = 21540,parent_id = 2,x1 = 21745,y1 = 28575,pk = true,drop_mask = 3,mark = false,idx = 33,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫三层',exp = 1,y0 = 28435, },
[34] = {x0 = 21855,parent_id = 2,x1 = 22010,y1 = 28200,pk = true,drop_mask = 3,mark = false,idx = 34,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫未知1',exp = 1,y0 = 28035, },
[35] = {x0 = 21885,parent_id = 2,x1 = 21922,y1 = 28055,pk = true,drop_mask = 1,mark = false,idx = 35,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫未知1大厅',exp = 1,y0 = 28040, },
[36] = {x0 = 21543,parent_id = 2,x1 = 21650,y1 = 28381,pk = true,drop_mask = 3,mark = false,idx = 36,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫未知2',exp = 1,y0 = 28264, },
[37] = {x0 = 21557,parent_id = 2,x1 = 21589,y1 = 28386,pk = true,drop_mask = 0,mark = false,idx = 37,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫未知2大厅',exp = 1,y0 = 28367, },
[38] = {x0 = 21748,parent_id = 2,x1 = 21765,y1 = 28370,pk = true,drop_mask = 1,mark = false,idx = 38,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫未知3大厅',exp = 1,y0 = 28345, },
[39] = {x0 = 21748,parent_id = 2,x1 = 21817,y1 = 28344,pk = true,drop_mask = 3,mark = false,idx = 39,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫未知3',exp = 1,y0 = 28304, },
[40] = {x0 = 21896,parent_id = 2,x1 = 21926,y1 = 28349,pk = true,drop_mask = 3,mark = false,idx = 40,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫BOOS房',exp = 1,y0 = 28304, },
[41] = {x0 = 22033,parent_id = 2,x1 = 22047,y1 = 28510,pk = true,drop_mask = 1,mark = false,idx = 41,bgm = 'AbandonedMine3F_Main',map_name = '人族地宫安全屋',exp = 1,y0 = 28498, },
[42] = {x0 = 20878,x1 = 21061,y1 = 37590,pk = true,drop_mask = 3,mark = false,idx = 42,bgm = 'AbandonedMine3F_Main',map_name = '花园',exp = 1,y0 = 37526, },
[43] = {x0 = 20820,parent_id = 42,x1 = 20872,y1 = 37563,pk = true,drop_mask = 3,mark = false,idx = 43,bgm = 'AbandonedMine3F_Main',map_name = '花园通道',exp = 1,y0 = 37515, },
[44] = {x0 = 20883,parent_id = 42,x1 = 20951,y1 = 37501,pk = true,drop_mask = 3,mark = false,idx = 44,bgm = 'AbandonedMine3F_Main',map_name = '花园-药园',exp = 1,y0 = 37432, },
[45] = {x0 = 20880,parent_id = 42,x1 = 20916,y1 = 37354,pk = true,drop_mask = 3,mark = false,idx = 45,bgm = 'AbandonedMine3F_Main',map_name = '花园-监牢',exp = 1,y0 = 37304, },
[46] = {x0 = 20839,parent_id = 42,x1 = 21062,y1 = 37335,pk = true,drop_mask = 3,mark = false,idx = 46,bgm = 'AbandonedMine3F_Main',map_name = '花园-通道',exp = 1,y0 = 37183, },
[47] = {x0 = 20844,parent_id = 42,x1 = 20892,y1 = 37134,pk = true,drop_mask = 3,mark = false,idx = 47,bgm = 'AbandonedMine3F_Main',map_name = '花园-地下室',exp = 1,y0 = 37094, },
[48] = {x0 = 20932,parent_id = 42,x1 = 21012,y1 = 37170,pk = true,drop_mask = 3,mark = false,idx = 48,bgm = 'AbandonedMine3F_Main',map_name = '花园-教堂',exp = 1,y0 = 37092, },
[49] = {x0 = 22994,parent_id = 42,x1 = 23029,y1 = 37170,pk = true,drop_mask = 3,mark = false,idx = 49,bgm = 'AbandonedMine3F_Main',map_name = '花园-中厅',exp = 1,y0 = 37088, },
[50] = {x0 = 23004,parent_id = 42,x1 = 23127,y1 = 37503,pk = true,drop_mask = 3,mark = false,idx = 50,bgm = 'AbandonedMine3F_Main',map_name = '花园-食堂',exp = 1,y0 = 37457, },
[51] = {x0 = 23045,parent_id = 42,x1 = 23127,y1 = 37672,pk = true,drop_mask = 3,mark = false,idx = 51,bgm = 'AbandonedMine3F_Main',map_name = '花园-礼堂',exp = 1,y0 = 37611, },
[52] = {x0 = 22769,parent_id = 42,x1 = 23173,y1 = 37697,pk = true,drop_mask = 3,mark = false,idx = 52,bgm = 'AbandonedMine3F_Main',map_name = '花园-环形通道',exp = 1,y0 = 37529, },
[53] = {x0 = 23152,parent_id = 42,x1 = 23177,y1 = 37497,pk = true,drop_mask = 3,mark = false,idx = 53,bgm = 'AbandonedMine3F_Main',map_name = '花园-会客厅',exp = 1,y0 = 37462, },
[54] = {x0 = 23050,parent_id = 2,x1 = 23081,y1 = 34531,pk = true,drop_mask = 3,mark = false,idx = 54,bgm = 'SealedLand',map_name = '足球场',exp = 1,y0 = 34486, },
[55] = {x0 = 23260,parent_id = 2,x1 = 23283,y1 = 35014,pk = true,drop_mask = 3,mark = false,idx = 55,bgm = 'AbandonedMine3F_Main',map_name = '神奇的区域',exp = 1,y0 = 34993, },
[56] = {x0 = 24385,x1 = 24659,y1 = 27122,pk = true,drop_mask = 3,mark = false,idx = 56,bgm = 'SealedLand',map_name = '瓦特岛240-300',exp = 10,y0 = 26684, },
[57] = {x0 = 20916,parent_id = 2,x1 = 20966,y1 = 28447,pk = true,drop_mask = 3,mark = false,idx = 57,bgm = 'AbandonedMine3F_Main',map_name = '营地',exp = 1,y0 = 28371, },
[58] = {x0 = 20861,parent_id = 2,x1 = 20869,y1 = 28328,pk = true,drop_mask = 3,mark = false,idx = 58,bgm = 'AbandonedMine3F_Main',map_name = 'BOOS房通道',exp = 1,y0 = 28322, },
[59] = {x0 = 22836,parent_id = 8,x1 = 23315,y1 = 28478,pk = true,drop_mask = 3,mark = false,idx = 59,bgm = 'DephirothChamber2_BossRoom',map_name = '精灵地宫一层',exp = 1,y0 = 28007, },
[60] = {x0 = 22881,parent_id = 8,x1 = 22930,y1 = 28113,pk = true,drop_mask = 3,mark = false,idx = 60,bgm = 'AbandonedMine3F_Main',map_name = '精灵地宫传送间',exp = 1,y0 = 28065, },
[61] = {x0 = 22744,parent_id = 2,x1 = 22830,y1 = 34407,pk = true,drop_mask = 3,mark = false,idx = 61,bgm = 'SealedLand',map_name = '人城争夺战',exp = 1,y0 = 34291, },
[62] = {x0 = 20841,parent_id = 2,x1 = 21251,y1 = 35709,pk = true,drop_mask = 3,mark = false,idx = 62,bgm = 'SealedLand',map_name = '白虎岛屿',exp = 1,y0 = 35324, },
[63] = {x0 = 24479,x1 = 24484,y1 = 34925,pk = true,drop_mask = 1,mark = false,idx = 63,map_name = '地宫门口传送至地宫',exp = 10,y0 = 34915, },
[64] = {x0 = 21156,x1 = 21160,y1 = 28624,pk = true,drop_mask = 1,mark = false,idx = 64,map_name = '地宫内部传送至门口',exp = 1,y0 = 28618, },
[65] = {x0 = 25388,x1 = 28546,y1 = 27000,pk = true,drop_mask = 3,mark = false,idx = 65,bgm = 'AbandonedMine3F_Main',map_name = '副本四白天',exp = 1,y0 = 24778, },
[66] = {x0 = 20838,x1 = 20973,y1 = 34026,pk = true,drop_mask = 3,mark = false,idx = 66,bgm = 'PetLand',map_name = '乐园',exp = 1,y0 = 33907, },
[67] = {x0 = 24097,x1 = 24336,y1 = 37353,pk = true,drop_mask = 3,mark = false,idx = 67,bgm = 'AbandonedMine3F_Main',map_name = '芭蕉洞',exp = 1,y0 = 37088, },
[68] = {x0 = 20807,x1 = 23405,y1 = 27310,pk = true,drop_mask = 2,mark = false,idx = 68,bgm = 'VerosNewCastle',map_name = '萨洛茨',exp = 1,y0 = 24712, },
[69] = {x0 = 20807,x1 = 22105,y1 = 36410,pk = true,drop_mask = 3,mark = false,idx = 69,bgm = 'SealedLand',map_name = '封印之地',exp = 1,y0 = 35112, },
[70] = {x0 = 24707,x1 = 27305,y1 = 36410,pk = true,drop_mask = 3,mark = false,idx = 70,bgm = 'SY_LoveAndLoss',map_name = '南达利亚东部地区',exp = 1,y0 = 33812, },
[71] = {x0 = 20807,x1 = 21455,y1 = 29258,pk = true,drop_mask = 1,mark = false,idx = 71,bgm = 'SY_ElDorado',map_name = '莱蒂尼斯地宫',exp = 1,y0 = 27962, },
[72] = {x0 = 21457,x1 = 22105,y1 = 28610,pk = true,drop_mask = 1,mark = false,idx = 72,bgm = 'SealedLand',map_name = '莱蒂尼斯地宫三层',exp = 1,y0 = 27962, },
[73] = {x0 = 22757,x1 = 24055,y1 = 29260,pk = true,drop_mask = 3,mark = false,idx = 73,bgm = 'FrozenLand',map_name = '精灵地宫',exp = 1,y0 = 27962, },

}

---@class kx_map_data
local kx_map_data =
{
	
---索引
idx = 0,
---地图名字
map_name = nil,
---左下角
x0 = 0,
---左下角
y0 = 0,
---右上角
x1 = 0,
---右上角
y1 = 0,
---允许PK
pk = false,
---背景音乐
bgm = nil,
---序号
parent_id = 0,
---是否允许位置登记
mark = false,
---经验倍率
exp = 0,
---掉落掩码
drop_mask = 0,
}

local indexTable = 
{
	__index = function()
		return kx_map_data
	end,
	__newindex = function (t,k,v)
		error('lua表格不允许修改！！' .. debug.traceback())
	end
}

setmetatable(_kx_map_table, indexTable)

kx_map_table = _kx_map_table
return _kx_map_table