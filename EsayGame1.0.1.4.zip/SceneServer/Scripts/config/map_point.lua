

local m ={
    ["港口"] = {PosX = 23804, PosY = 35914},
    ["水上村"] = {PosX = 24269, PosY = 35472},
    ["萨洛茨"]= {PosX = 21827, PosY = 26503},
}

MapPointConfig = m
return