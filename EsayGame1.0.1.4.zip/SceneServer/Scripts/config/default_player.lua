

local newPlayer = {
	["OneHand"] = {BirthPlace = "Ladianes", ForcePoints = 5000, AgilityPoints = 5000, MentalPoints = 5000, WhiteMagic = 0, RedMagic = 0, BlueMagic = 0, YellowMagic = 0, BlackMagic = 5000, Direction = 0, X = 22965, Y = 34238, Gold = 100000}



}
NewPlayer = newPlayer
return newPlayer