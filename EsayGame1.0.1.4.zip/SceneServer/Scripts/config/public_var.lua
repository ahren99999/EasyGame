

local m = {
    Temp_MoveSpeed = 1,
}

local map = {
    [m.Temp_MoveSpeed] = "临时属性_移动速度"
}