
---管理员名单
local m = {
    ["Ahren01"] = 10,
    ["Ahren02"] = 8,
    ["Ahren03"] = 10,
    ["Ahren04"] = 10,
    ["Ahren05"] = 10,
}

Admin = m
return m