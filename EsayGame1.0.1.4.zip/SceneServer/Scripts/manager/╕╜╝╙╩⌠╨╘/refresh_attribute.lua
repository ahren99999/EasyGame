
---属性刷新实现
local m = {}

---核心实现方法
---@param player Player
function m.RefreshAttribute(player)
    
end








RefreshAttribute = m
return m